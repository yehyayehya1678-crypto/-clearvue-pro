ClearVue Pro v4 — launch-ready website

Files:
- index.html
- styles.css
- script.js
- thanks.html
- assets/

Upload the entire ZIP/folder to Netlify so the assets folder remains beside index.html.

This version includes the real ClearVue Pro product photos, a shorter mobile-friendly sales page, cleaned customer-facing wording, a compact quick-order bar, checkout form, FAQ, and order confirmation page.

The checkout uses Netlify Forms to collect order requests. No online card payment is processed on this page.
