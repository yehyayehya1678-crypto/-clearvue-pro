const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();

// Keep the mobile quick-order bar from covering the active checkout form.
const buybar = document.querySelector('.mobile-buybar');
const checkout = document.getElementById('checkout');
if (buybar && checkout && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver(([entry]) => {
    buybar.classList.toggle('is-hidden', entry.isIntersecting);
  }, { threshold: 0.12 });
  observer.observe(checkout);
}
